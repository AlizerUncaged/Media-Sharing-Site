﻿namespace Utilities.Models;

public enum AccountType
{
    Administrator, Member
}