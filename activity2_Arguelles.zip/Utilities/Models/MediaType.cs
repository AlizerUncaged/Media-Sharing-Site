﻿namespace Utilities.Models;

public enum MediaType
{
    Video, Audio
}